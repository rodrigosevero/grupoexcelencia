<?php

return [
    'date_format'               => 'Y-m-d',
    'time_format'               => 'H:i:s',
    'primary_language'          => 'pt-BR',
    'available_languages'       => [
        'en' => 'English',
    ],
    'registration_default_role' => '2',
];
