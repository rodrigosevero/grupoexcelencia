<?php

return [
    'site_title' => 'Grupo Excelência',
];
